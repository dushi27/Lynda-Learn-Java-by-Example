package com.example.jdbc;

public class EncryptTest {

	public static void main(String[] args) {
		DatabaseTest test = new DatabaseTest();
		test.keyTest();
	}
}
